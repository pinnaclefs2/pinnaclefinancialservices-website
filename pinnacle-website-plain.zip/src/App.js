import React from "react";
import "./App.css";

function App() {
  return (
    <div className="container">
      <header className="header">
        <img src="/logo.png" alt="Pinnacle Logo" className="logo" />
        <a href="/login" className="login-btn">Login</a>
      </header>
      <main className="main">
        <h1>Login to Trade Online with Pinnacle Financial Services</h1>
        <p>Experience a seamless online trading journey with our platform.</p>
        <div className="services">
          <span>Retail Investors</span>
          <span>HNIs</span>
          <span>HUFs</span>
          <span>Traders</span>
        </div>
        <form className="lead-form">
          <input type="text" placeholder="Your Name" />
          <input type="email" placeholder="Email Address" />
          <button type="submit">Get Started</button>
        </form>
      </main>
      <footer className="footer">
        &copy; {new Date().getFullYear()} Pinnacle Financial Services. All rights reserved.
      </footer>
    </div>
  );
}

export default App;
